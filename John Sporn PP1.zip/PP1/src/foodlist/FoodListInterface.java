package foodlist;

public interface FoodListInterface {
	
	void add(String food);
	
	boolean onTheMenu(String food);

}
